---
name: Feature request
about: Issue template for a feature request.
title: ''
labels: enhancement, needs triage
assignees: ''
---

**Please do not file new issues in this repository.**

All new feature requests should be filed in the
[Media3 issue tracker](https://github.com/androidx/media/issues/new?template=feature_request.md).

We will continue to update and reply to existing issues in this repository and
will keep existing feature requests active.

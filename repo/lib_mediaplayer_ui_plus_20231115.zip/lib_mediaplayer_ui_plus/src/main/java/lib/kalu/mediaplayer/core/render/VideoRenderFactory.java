package lib.kalu.mediaplayer.core.render;

import android.content.Context;

public interface VideoRenderFactory {
    VideoRenderApi create(Context context);
}

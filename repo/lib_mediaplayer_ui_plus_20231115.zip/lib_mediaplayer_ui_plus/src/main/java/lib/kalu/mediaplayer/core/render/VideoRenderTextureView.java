/*
Copyright 2017 yangchong211（github.com/yangchong211）

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
package lib.kalu.mediaplayer.core.render;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.SurfaceTexture;
import android.os.Build;
import android.view.KeyEvent;
import android.view.Surface;
import android.view.TextureView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import lib.kalu.mediaplayer.config.player.PlayerType;
import lib.kalu.mediaplayer.core.kernel.video.VideoKernelApi;
import lib.kalu.mediaplayer.util.MPLogUtil;


/**
 * <pre>
 *     desc  : 重写TextureView，适配视频的宽高和旋转
 *     revise: 1.继承View，具有view的特性，比如移动，旋转，缩放，动画等变化。支持截图
 *             8.必须在硬件加速的窗口中使用，占用内存比SurfaceView高，在5.0以前在主线程渲染，5.0以后有单独的渲染线程。
 * </pre>
 */
public class VideoRenderTextureView extends TextureView implements VideoRenderApi {

    private SurfaceTexture mSurfaceTexture;
    @Nullable
    private VideoKernelApi mKernel;
    private Surface mSurface;
    private SurfaceTextureListener mSurfaceTextureListener;

    public VideoRenderTextureView(Context context) {
        super(context);
        init();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        MPLogUtil.log("VideoRenderTextureView => onDetachedFromWindow => " + this);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        MPLogUtil.log("VideoRenderTextureView => onAttachedToWindow => " + this);
    }

    @Override
    public void init() {
        setFocusable(false);
        setFocusableInTouchMode(false);
        addListener();
    }

    @Override
    public void addListener() {
        mSurfaceTextureListener = new SurfaceTextureListener() {
            /**
             * SurfaceTexture准备就绪
             * @param surfaceTexture            surface
             * @param width                     WIDTH
             * @param height                    HEIGHT
             */
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int width, int height) {
                MPLogUtil.log("VideoRenderTextureView => onSurfaceTextureAvailable => " + this);
                if (mSurfaceTexture != null) {
                    setSurfaceTexture(mSurfaceTexture);
                } else {
                    mSurfaceTexture = surfaceTexture;
                    mSurface = new Surface(surfaceTexture);
                    if (mKernel != null) {
                        int w = getWidth();
                        int h = getHeight();
                        mKernel.setSurface(mSurface, w, h);
                    }
                }
            }

            /**
             * SurfaceTexture缓冲大小变化
             * @param surface                   surface
             * @param width                     WIDTH
             * @param height                    HEIGHT
             */
            @Override
            public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {
            }

            /**
             * SurfaceTexture即将被销毁
             * @param surface                   surface
             */
            @Override
            public boolean onSurfaceTextureDestroyed(@NonNull SurfaceTexture surface) {
                return false;
            }

            /**
             * SurfaceTexture通过updateImage更新
             * @param surface                   surface
             */
            @Override
            public void onSurfaceTextureUpdated(SurfaceTexture surface) {
                try {
                    if (null == mKernel)
                        throw new Exception("mKernel error: null");
                    mKernel.onUpdateTimeMillis();
                } catch (Exception e) {
                    MPLogUtil.log("VideoRenderTextureView => onSurfaceTextureUpdated => " + e.getMessage());
                }
            }
        };
        setSurfaceTextureListener(mSurfaceTextureListener);
    }

    /**
     * 释放资源
     */
    @Override
    public void release() {
        if (mSurfaceTexture != null) {
            mSurfaceTexture.release();
        }
        if (mSurface != null) {
            mSurface.release();
        }
        if (null != mSurfaceTextureListener) {
            mSurfaceTextureListener = null;
        }
    }

    @Override
    public void setKernel(@NonNull VideoKernelApi player) {
        this.mKernel = player;
    }

    @Override
    public String screenshot() {
        Context context = getContext();
        Bitmap bitmap = getBitmap();
        return saveBitmap(context, bitmap);
    }

    @Override
    public void updateBuffer(int delayMillis) {

    }

    @Override
    public boolean hasFocus() {
        return false;
    }

    @Override
    public boolean hasFocusable() {
        return false;
    }

    @Override
    public boolean hasExplicitFocusable() {
        return false;
    }

    @Override
    public boolean hasWindowFocus() {
        return false;
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        return false;
    }

    /****************/

    /************/

    /**
     * 记得一定要重新写这个方法，如果角度发生了变化，就重新绘制布局
     * 设置视频旋转角度
     *
     * @param rotation 角度
     */
    @Override
    public void setRotation(float rotation) {
        if (rotation != getRotation()) {
            super.setRotation(rotation);
            requestLayout();
        }
    }

    /***************/

    int mVideoWidth = 0;
    int mVideoHeight = 0;
    int mVideoScaleType = 0;
    int mVideoRotation = 0;

    @Override
    public void setVideoSize(@NonNull int videoWidth, @NonNull int videoHeight) {
        try {
            if (videoWidth <= 0 || videoHeight <= 0)
                throw new Exception("videoWidth error: " + videoWidth + ", videoHeight error: " + videoHeight);
            mVideoWidth = videoWidth;
            mVideoHeight = videoHeight;
            requestLayout();
        } catch (Exception e) {
            MPLogUtil.log("RenderSurfaceView => setVideoSize => " + e.getMessage());
        }
    }

    @Override
    public void setVideoRotation(@PlayerType.RotationType.Value int videoRotation) {
        this.mVideoRotation = videoRotation;
        requestLayout();
    }

    @Override
    public void setVideoScaleType(@PlayerType.ScaleType.Value int scaleType) {
        this.mVideoScaleType = scaleType;
        requestLayout();
    }


    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        try {
            int[] measureSpec = doMeasureSpec(widthMeasureSpec, heightMeasureSpec, mVideoScaleType, mVideoRotation, mVideoWidth, mVideoHeight);
            if (null == measureSpec || measureSpec.length != 2)
                throw new Exception("measureSpec error: " + measureSpec);
            int width = measureSpec[0];
            int height = measureSpec[1];
            int specW = MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY);
            int specH = MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY);
            super.onMeasure(specW, specH);
//            setMeasuredDimension(measureSpec[0], measureSpec[1]);
//            getHolder().setFixedSize(measureSpec[0], measureSpec[1]);
        } catch (Exception e) {
            MPLogUtil.log("VideoRenderTextureView => onMeasure => " + e.getMessage());
        }
    }
}
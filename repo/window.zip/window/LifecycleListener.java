package lib.kalu.mediaplayer.window;


interface LifecycleListener {

    void onShow();

    void onHide();

    void onPostHide();
}

//
//  rtd.h
//  rtd
//
//  Created by gongjun on 6/14/22.
//

#import <Foundation/Foundation.h>
#import "rtd_api.h"
//! Project version number for rtd.
FOUNDATION_EXPORT double rtdVersionNumber;

//! Project version string for rtd.
FOUNDATION_EXPORT const unsigned char rtdVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <rtd/PublicHeader.h>



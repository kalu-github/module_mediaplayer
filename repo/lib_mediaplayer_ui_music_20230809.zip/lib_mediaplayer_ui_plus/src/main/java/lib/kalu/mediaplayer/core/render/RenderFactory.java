package lib.kalu.mediaplayer.core.render;

import android.content.Context;

public interface RenderFactory {
    RenderApi create(Context context);
}

package lib.kalu.mediaplayer.core.kernel.audio;

public interface OnMusicPlayerChangeListener {
    void onStart();

    void onEnd();
    void onError();
}

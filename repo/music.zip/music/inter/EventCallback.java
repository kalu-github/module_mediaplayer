package lib.kalu.mediaplayer.core.kernel.music.inter;


public interface EventCallback<T> {
    void onEvent(T t);
}
